<?php
echo file_exists('progress.txt') ? file_get_contents('progress.txt') : "0";

